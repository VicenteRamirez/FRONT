const bodyparser = require('body-parser');
const mysql  = require('mysql');
const express = require('express');
const cors = require('cors')
var app = express();

app.use(cors());
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());
//conexión a la base de datos 
var mysqlConnection = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'Obesin10.',
    database:'crudmysql',
});

//intentar conectar a la base de datos
mysqlConnection.connect((err)=>{
    if(!err)
    console.log('conexion a base de datos exitosa');
    else
    console.log('conexion a base de datos fallida\n Error :'+JSON.stringify(err, undefined,2));
});


app.listen(3002,() =>console.log('Express server esta corriendo en el puerto número 3002'));


//obtener todos los clietes
app.get('/clientes',(req,res)=>{
    mysqlConnection.query('SELECT * FROM clientes',(err,rows, fileds)=>{
        if(!err)
        res.send(rows)
        else
        console.log(err);   
    })
});

//obtener un cliente
app.get('/clientes/:id',(req,res)=>{
    mysqlConnection.query('SELECT * FROM clientes WHERE clienteid = ?',[req.params.id],(err,rows, fileds)=>{
        if(!err)
        res.send(rows)
        else
        console.log(err);   
    })
});

//borrar un cliente
app.delete('/clientes/:id',(req,res)=>{
    mysqlConnection.query('DELETE FROM clientes WHERE clienteid = ?',[req.params.id],(err,rows, fileds)=>{
        if(err){
            res.write(JSON.stringify({
                error: true,
                error_object: err
            }));
            res.end();
        }else{
            res.write(JSON.stringify(rows));
            res.end();
        }  
    })
});



/*
//insertar un cliente

app.post('/clientes', (req, res) => {
    let cli = req.body;
    var sql = "SET @clienteid = ?;SET @nombre = ?;SET @apellido = ?;SET @telefono = ?;SET @direccion = ?; \
    CALL ClienteAddOrEdit(@clienteid,@nombre,@apellido,@telefono,@direccion);";
    mysqlConnection.query(sql, [cli.clienteid, cli.nombre, cli.apellido, cli.telefono,cli.direccion], (err, rows, fields) => {
        if (!err)
            rows.forEach(element => {
                if(element.constructor == Array)
                res.send('Inserted employee id : '+element[0].clienteid);
            });
        else
            console.log(err);
    })
});
*/
/*
//editar un cliente

app.put('/clientes', (req, res) => {
    let cli = req.body;
    var sql = "SET @clienteid = ?;SET @nombre = ?;SET @apellido = ?;SET @telefono = ?;SET @direccion = ?; \
    CALL ClienteAddOrEdit(@clienteid,@nombre,@apellido,@telefono,@direccion);";
    mysqlConnection.query(sql, [cli.clienteid, cli.nombre, cli.apellido, cli.telefono,cli.direccion], (err, rows, fields) => {
        if (!err)
            res.send('Actualizado correctamente');
        else
            console.log(err);
    })
});
*/

app.post('/clientes', (req, res) => {
    const data = req.body;
    mysqlConnection.query('INSERT INTO clientes set ?',[data],(err,rows, fileds)=>{
        if(err){
            res.write(JSON.stringify({
                err:true,
                error_object:err
            }));
            res.end();
        }else{
            res.write(JSON.stringify(rows));
            res.end();
        }
    });
});

app.put('/clientes/:id', (req, res) => {
    const data = req.body;
    mysqlConnection.query('UPDATE clientes set ? WHERE id = ?',[data,req.params.id],(err,rows, fileds)=>{
        if(err){
            res.write(JSON.stringify({
                err:true,
                error_object:err
            }));
            res.end();
        }else{
            res.write(JSON.stringify(rows));
            res.end();        
        }
    });
});